package com.Bookstore.samulibookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamulibookstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
